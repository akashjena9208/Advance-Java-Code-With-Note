package com.jsp.springboot.ems;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootEmployeeDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
