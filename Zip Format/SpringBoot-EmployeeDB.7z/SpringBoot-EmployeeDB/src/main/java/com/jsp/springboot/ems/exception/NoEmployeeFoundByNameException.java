package com.jsp.springboot.ems.exception;

public class NoEmployeeFoundByNameException extends RuntimeException {

	private String message;

	public String getMessage() {
		return message;
	}

	public NoEmployeeFoundByNameException(String message) {
		this.message = message;
	}
}
