package com.jsp.springboot.ems.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jsp.springboot.ems.entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer>{

	// findBy
	List<Employee> findByEmployeeName(String employeeName);
	List<Employee> findByEmployeeNameAndExperience(String employeeName,int experience);
	List<Employee> findBySalary(int salary);
	List<Employee> findBySalaryGreaterThan(int salary);
	List<Employee> findBySalaryLessThan(int salary);
	List<Employee> findBySalaryBetween(int salary1,int salary2);
	Employee findByEmail(String email);
	
	//deleteBy
	List<Employee> deleteByEmployeeName(String employeeName);
	List<Employee> deleteByEmployeeNameAndExperience(String employeeName,int experience);
	List<Employee> deleteBySalary(int salary);
	List<Employee> deleteBySalaryGreaterThan(int salary);
	List<Employee> deleteBySalaryLessThan(int salary);
	List<Employee> deleteBySalaryBetween(int salary1,int salary2);
	Employee deleteByEmail(String email);
	
}
