package com.jsp.springboot.ems.exception;

public class EmployeeNotFoundByIdException extends RuntimeException {

	private String message;

	public String getMessage() {
		return message;
	}

	public EmployeeNotFoundByIdException(String message) {
		this.message = message;
	}
}
