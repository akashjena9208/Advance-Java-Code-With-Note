package com.jsp.springboot.ems.service;

import java.util.List;

import com.jsp.springboot.ems.entity.Employee;

public interface EmployeeService {

	public Employee addEmployee(Employee employee);

	public List<Employee> findAllEmployees();

	public Employee findEmployeeById(int employeeId);

	public Employee deleteEmployeeById(int employeeId);

	public Employee updateByEmployeeId(int employeeId, Employee updatedEmployee);

	public List<Employee> findEmployeeByName(String employeeName);

	public List<Employee> findEmployeeByNameAndExperience(String employeeName, int experience);

	public List<Employee> findEmployeeBySalary(int salary);

	public List<Employee> findEmployeeBySalaryGreaterThan(int salary);

	public List<Employee> findEmployeeBySalaryLessThan(int salary);

	public List<Employee> findEmployeeBySalaryBetween(int salary1,int salary2);

	public Employee findEmployeeByEmail(String email);
	
	public List<Employee> deletEmployeeByName(String employeeName);
	
	public List<Employee> deleteEmployeeByNameAndExperience(String employeeName, int experience);
	
	public List<Employee> deleteEmployeeBySalary(int salary);
	
	public List<Employee> deleteEmployeeBySalaryGreaterThan(int salary);
	
	public List<Employee> deleteEmployeeBySalaryLessThan(int salary);
	
	public List<Employee> deleteEmployeeBySalaryBetween(int salary1,int salary2);
	
	public Employee deleteEmployeeByEmail(String email);
}
