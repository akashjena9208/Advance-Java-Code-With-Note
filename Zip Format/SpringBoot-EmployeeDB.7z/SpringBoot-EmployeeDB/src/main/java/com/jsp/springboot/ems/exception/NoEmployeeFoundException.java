package com.jsp.springboot.ems.exception;

public class NoEmployeeFoundException extends RuntimeException {

	private String message;
	
	public String getMessage() {
		return message;
	}

	public NoEmployeeFoundException(String message) {
		this.message = message;
	}
}
