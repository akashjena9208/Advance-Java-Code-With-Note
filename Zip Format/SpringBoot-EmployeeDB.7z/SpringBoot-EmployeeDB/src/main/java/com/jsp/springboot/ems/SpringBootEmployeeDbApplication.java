package com.jsp.springboot.ems;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootEmployeeDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootEmployeeDbApplication.class, args);
	}

}
