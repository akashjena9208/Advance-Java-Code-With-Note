package com.jsp.springboot.ems.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jsp.springboot.ems.entity.Employee;
import com.jsp.springboot.ems.exception.EmployeeNotFoundByIdException;
import com.jsp.springboot.ems.exception.NoEmployeeFoundByNameException;
import com.jsp.springboot.ems.exception.NoEmployeeFoundException;
import com.jsp.springboot.ems.repository.EmployeeRepository;
import com.jsp.springboot.ems.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService{

	@Autowired
	private EmployeeRepository employeeRepository;

	@Override
	public Employee addEmployee(Employee employee) {
		return employeeRepository.save(employee);
	}

	@Override
	public List<Employee> findAllEmployees() {

		List<Employee> employees = employeeRepository.findAll();
		if(employees.isEmpty())
		{
			throw new NoEmployeeFoundException("No Employees found");
		}else {
			return employees;
		}
	}

	@Override
	public Employee findEmployeeById(int employeeId) {
		Optional<Employee> optional = employeeRepository.findById(employeeId);
		if(optional.isEmpty())
		{
			throw new EmployeeNotFoundByIdException("Employee not found by Id");
		}else {
			Employee employee = optional.get();
			return employee;
		}
	}

	@Override
	public Employee updateByEmployeeId(int employeeId, Employee updatedEmployee) {
		Optional<Employee> optional = employeeRepository.findById(employeeId);
		if(optional.isEmpty()) {
			throw new EmployeeNotFoundByIdException("Employee not found by Id");
		}else {
			Employee existingEmployee = optional.get();
			updatedEmployee.setEmployeeId(existingEmployee.getEmployeeId());
			return employeeRepository.save(updatedEmployee);
		}
	}

	@Override
	public Employee deleteEmployeeById(int employeeId) {
		Optional<Employee> optional = employeeRepository.findById(employeeId);
		if(optional.isEmpty())
		{
			throw new EmployeeNotFoundByIdException("Employee not found by Id");
		}else {
			Employee employee = optional.get();
			employeeRepository.delete(employee);
			return employee;
		}
	}

	@Override
	public List<Employee> findEmployeeByName(String employeeName) {
		List<Employee> employees = employeeRepository.findByEmployeeName(employeeName);
		if(employees.isEmpty())
		{
			throw new NoEmployeeFoundByNameException("No Employees found by Name");
		}else {
			return employees;
		}	
	}

	@Override
	public List<Employee> findEmployeeByNameAndExperience(String employeeName, int experience) {
		List<Employee> employees = employeeRepository.findByEmployeeName(employeeName);
		if(employees.isEmpty())
		{
			return null;
		}else {
			return employees;
		}		
	}

	@Override
	public List<Employee> findEmployeeBySalary(int salary) {
		List<Employee> employees = employeeRepository.findBySalary(salary);
		if(employees.isEmpty())
		{
			return null;
		}else {
			return employees;
		}
	}

	@Override
	public List<Employee> findEmployeeBySalaryGreaterThan(int salary) {
		List<Employee> employees = employeeRepository.findBySalaryGreaterThan(salary);
		if(employees.isEmpty())
		{
			return null;
		}else {
			return employees;
		}
	}

	@Override
	public List<Employee> findEmployeeBySalaryLessThan(int salary) {
		List<Employee> employees = employeeRepository.findBySalaryLessThan(salary);
		if(employees.isEmpty())
		{
			return null;
		}else {
			return employees;
		}
	}

	@Override
	public List<Employee> findEmployeeBySalaryBetween(int salary1, int salary2) {
		List<Employee> employees = employeeRepository.findBySalaryBetween(salary1,salary2);
		if(employees.isEmpty())
		{
			return null;
		}else {
			return employees;
		}
	}

	@Override
	public Employee findEmployeeByEmail(String email) {
		Employee employee = employeeRepository.findByEmail(email);
		if(employee == null)
		{
			return null;
		}else {
			return employee;
		}
	}

	@Override
	public List<Employee> deletEmployeeByName(String employeeName) {
		List<Employee> employees = employeeRepository.findByEmployeeName(employeeName);		
		if(employees.isEmpty())
		{
			return null;
		}else {
			employeeRepository.deleteAll(employees);
			return employees;
		}
	}

	@Override
	public List<Employee> deleteEmployeeByNameAndExperience(String employeeName, int experience) {
		List<Employee> employees = employeeRepository.findByEmployeeNameAndExperience(employeeName,experience);		
		if(employees.isEmpty())
		{
			return null;
		}else {
			employeeRepository.deleteAll(employees);
			return employees;
		}
	}

	@Override
	public List<Employee> deleteEmployeeBySalary(int salary) {
		List<Employee> employees = employeeRepository.findBySalary(salary);		
		if(employees.isEmpty())
		{
			return null;
		}else {
			employeeRepository.deleteAll(employees);
			return employees;
		}
	}

	@Override
	public List<Employee> deleteEmployeeBySalaryGreaterThan(int salary) {
		List<Employee> employees = employeeRepository.findBySalaryGreaterThan(salary);		
		if(employees.isEmpty())
		{
			return null;
		}else {
			employeeRepository.deleteAll(employees);
			return employees;
		}
	}

	@Override
	public List<Employee> deleteEmployeeBySalaryLessThan(int salary) {
		List<Employee> employees = employeeRepository.findBySalaryLessThan(salary);		
		if(employees.isEmpty())
		{
			return null;
		}else {
			employeeRepository.deleteAll(employees);
			return employees;
		}
	}

	@Override
	public List<Employee> deleteEmployeeBySalaryBetween(int salary1, int salary2) {
		List<Employee> employees = employeeRepository.findBySalaryBetween(salary1,salary2);		
		if(employees.isEmpty())
		{
			return null;
		}else {
			employeeRepository.deleteAll(employees);
			return employees;
		}
	}

	@Override
	public Employee deleteEmployeeByEmail(String email) {
		Employee employee = employeeRepository.findByEmail(email);
		if(employee == null)
		{
			return null;
		}else {
			employeeRepository.delete(employee);
			return employee;
		}
	}

}
