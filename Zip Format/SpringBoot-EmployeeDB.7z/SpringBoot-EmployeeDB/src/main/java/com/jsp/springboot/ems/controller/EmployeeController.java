package com.jsp.springboot.ems.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.jsp.springboot.ems.entity.Employee;
import com.jsp.springboot.ems.service.EmployeeService;
import com.jsp.springboot.ems.utility.ResponseStructure;

//@Controller
//@ResponseBody
@RestController
@RequestMapping("/employees")
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;

	@PostMapping
	public ResponseEntity<ResponseStructure<Employee>> addEmployee(@RequestBody Employee employee) {

		Employee employee2 = employeeService.addEmployee(employee);

		ResponseStructure<Employee> responseStructure = new ResponseStructure<>();
		responseStructure.setStatusCode(HttpStatus.CREATED.value());
		responseStructure.setMessage("Employee object created successfully");
		responseStructure.setData(employee2);

		return new ResponseEntity<ResponseStructure<Employee>>(responseStructure, HttpStatus.CREATED);
	}

	@GetMapping
	public ResponseEntity<ResponseStructure<List<Employee>>> findAllEmployees() {
		List<Employee> employees = employeeService.findAllEmployees();

		ResponseStructure<List<Employee>> responseStructure = new ResponseStructure<>();
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setMessage("Employee objects found successfully");
		responseStructure.setData(employees);

		return new ResponseEntity<ResponseStructure<List<Employee>>>(responseStructure, HttpStatus.FOUND);
	}

	@GetMapping("/id/{employeeId}")
	public ResponseEntity<ResponseStructure<Employee>> findEmployeesById(@PathVariable int employeeId) {
		Employee employee = employeeService.findEmployeeById(employeeId);
		ResponseStructure<Employee> responseStructure = new ResponseStructure<>();
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setMessage("Employee object found successfully");
		responseStructure.setData(employee);

		return new ResponseEntity<ResponseStructure<Employee>>(responseStructure, HttpStatus.FOUND);
	}

	@GetMapping("/name")
	public ResponseEntity<ResponseStructure<List<Employee>>> findEmployeesByName(String employeeName) {
		List<Employee> employees = employeeService.findEmployeeByName(employeeName);
		ResponseStructure<List<Employee>> responseStructure = new ResponseStructure<>();
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setMessage("Employee object found successfully");
		responseStructure.setData(employees);
		
		return new ResponseEntity<ResponseStructure<List<Employee>>>(responseStructure, HttpStatus.FOUND);
	}
	
	@GetMapping("/name-and-experience")
	public ResponseEntity<ResponseStructure<List<Employee>>> findEmployeesByNameAndExperience(String employeeName,int experience) {
		List<Employee> employees = employeeService.findEmployeeByNameAndExperience(employeeName,experience);
		ResponseStructure<List<Employee>> responseStructure = new ResponseStructure<>();
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setMessage("Employee object found successfully");
		responseStructure.setData(employees);
		
		return new ResponseEntity<ResponseStructure<List<Employee>>>(responseStructure, HttpStatus.FOUND);
	}
	
	@GetMapping("/salary")
	public ResponseEntity<ResponseStructure<List<Employee>>> findEmployeesBySalary(int salary) {
		List<Employee> employees = employeeService.findEmployeeBySalary(salary);
		ResponseStructure<List<Employee>> responseStructure = new ResponseStructure<>();
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setMessage("Employee object found successfully");
		responseStructure.setData(employees);
		
		return new ResponseEntity<ResponseStructure<List<Employee>>>(responseStructure, HttpStatus.FOUND);
	}
	
	@GetMapping("/salary-greater-than")
	public ResponseEntity<ResponseStructure<List<Employee>>> findEmployeesBySalaryGreaterThan(int salary) {
		List<Employee> employees = employeeService.findEmployeeBySalaryGreaterThan(salary);
		ResponseStructure<List<Employee>> responseStructure = new ResponseStructure<>();
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setMessage("Employee object found successfully");
		responseStructure.setData(employees);
		
		return new ResponseEntity<ResponseStructure<List<Employee>>>(responseStructure, HttpStatus.FOUND);
	}
	
	@GetMapping("/salary-less-than")
	public ResponseEntity<ResponseStructure<List<Employee>>> findEmployeesBySalaryLessThan(int salary) {
		List<Employee> employees = employeeService.findEmployeeBySalaryLessThan(salary);
		ResponseStructure<List<Employee>> responseStructure = new ResponseStructure<>();
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setMessage("Employee object found successfully");
		responseStructure.setData(employees);
		
		return new ResponseEntity<ResponseStructure<List<Employee>>>(responseStructure, HttpStatus.FOUND);
	}
	
	@GetMapping("/salary-between")
	public ResponseEntity<ResponseStructure<List<Employee>>> findEmployeesBySalaryBetween(int salary1,int salary2) {
		List<Employee> employees = employeeService.findEmployeeBySalaryBetween(salary1,salary2);
		ResponseStructure<List<Employee>> responseStructure = new ResponseStructure<>();
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setMessage("Employee object found successfully");
		responseStructure.setData(employees);
		
		return new ResponseEntity<ResponseStructure<List<Employee>>>(responseStructure, HttpStatus.FOUND);
	}
	
	@GetMapping("/email")
	public ResponseEntity<ResponseStructure<Employee>> findEmployeesByEmail(String email) {
		Employee employees = employeeService.findEmployeeByEmail(email);
		ResponseStructure<Employee> responseStructure = new ResponseStructure<>();
		responseStructure.setStatusCode(HttpStatus.FOUND.value());
		responseStructure.setMessage("Employee object found successfully");
		responseStructure.setData(employees);
		
		return new ResponseEntity<ResponseStructure<Employee>>(responseStructure, HttpStatus.FOUND);
	}
	
	@PutMapping
	public ResponseEntity<ResponseStructure<Employee>> updateByEmployeeId(int employeeId,@RequestBody Employee updatedEmployee) {
		Employee employee = employeeService.updateByEmployeeId(employeeId,updatedEmployee);
		ResponseStructure<Employee> responseStructure = new ResponseStructure<>();
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMessage("Employee object updated successfully");
		responseStructure.setData(employee);

		return new ResponseEntity<ResponseStructure<Employee>>(responseStructure, HttpStatus.OK);
	}

	@DeleteMapping
	public ResponseEntity<ResponseStructure<Employee>> deleteEmployeeById(int employeeId) {
		Employee employee = employeeService.deleteEmployeeById(employeeId);
		ResponseStructure<Employee> responseStructure = new ResponseStructure<>();
		responseStructure.setStatusCode(HttpStatus.OK.value());
		responseStructure.setMessage("Employee object deleted successfully");
		responseStructure.setData(employee);

		return new ResponseEntity<ResponseStructure<Employee>>(responseStructure, HttpStatus.OK);
	}
}
